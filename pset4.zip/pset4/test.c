#include <stdio.h>
#include <stdlib.h>
//Stanford Portable Library
#include "gobjects.h"
#include "gwindow.h"


int main(void)
{
    //instantiate window
    Gwindow window = newGwindow(400,500);
}

